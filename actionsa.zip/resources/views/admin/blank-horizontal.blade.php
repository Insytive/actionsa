@extends('layouts.horizontal-bar.master')
@section('page-css')

@endsection
@section('main-content')
<div class="breadcrumb">
    <h1>Horizontal Sidebar</h1>
    <ul>
        <li><a href="">Starter</a></li>
        <li>Blank Page</li>
    </ul>
</div>
<div class="separator-breadcrumb border-top"></div>


<!-- Content Goes Here-->

@endsection

@section('page-js')


@endsection