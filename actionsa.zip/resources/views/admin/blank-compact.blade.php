@extends('layouts.compact.master')

@section('page-css')


@endsection
@section('main-content')
<div class="breadcrumb">
    <h1>Compact Sidebar</h1>
    <ul>
        <li><a href="">Starter</a></li>
        <li>Blank Page</li>
    </ul>
</div>
<div class="separator-breadcrumb border-top"></div>

@endsection

@section('page-js')

@endsection
