<template>
    <div>
        <p>This is the Lead registration form</p>
    </div>
</template>

<script>

</script>
