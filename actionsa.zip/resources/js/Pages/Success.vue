<template>
  <web-layout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Thank you!
      </h2>
    </template>

    <section class="registered">
      <div class="container">
        <span>
          <svg
            width="1em"
            height="1em"
            viewBox="0 0 16 16"
            class="bi bi-bookmark-check"
            fill="currentColor"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fill-rule="evenodd"
              d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z"
            />
            <path
              fill-rule="evenodd"
              d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z"
            />
          </svg>
        </span>
        <h2 class="registered__title">Thank you!</h2>
        <h4>We have received your submission and appreciate your support.</h4>

        <p>
          You will receive your digital membership card and further
          communication via email
        </p>
      </div>
    </section>
  </web-layout>
</template>

<script>
import WebLayout from "../Layouts/WebLayout";

export default {
  components: {
    WebLayout,
  },
};

window.setTimeout(function () {
  window.location.href = "https://www.actionsa.org.za/";
}, 5000);
</script>
